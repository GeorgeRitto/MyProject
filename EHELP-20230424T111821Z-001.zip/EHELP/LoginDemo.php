<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Login</title>
<style>
  .auth-page form
  {
  width:100%;
  max-width:300px;
  margin:100px auto 200px;
  text-align:center;
  }
  .form-field
  {
  width:100%;
  padding:8px 12px;
  margin-bottom:20px;
  border-radius:3px;
  border:1px solid #ccc;
  }
  .auth-page form input[type="submit"]
  {
  font-size:15px;
  background:#990000;
  color:#FFFFFF;
  border:1px solid #990000;
  padding:8px 12px;
  display:inline-block;
  }
  .auth-page form h1
  {
  color:#990000;
  }
  </style>
  </head>
 <body>
 <div class="auth-page">
  <form action="" method="" >
		  <h1>SIGN IN</h1>
		
			<input type="text" autocomplete="off" name="uname" class="form-field" placeholder="Username">
		
			<input type="password" autocomplete="new-password" name="upswd" class="form-field" placeholder="Password">
			<br>
			<input type="submit" value="Sign In">
		    
		  </form>
 </div>
 
 
</body>
</html>
