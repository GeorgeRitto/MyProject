<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Vigor A Industrial Category Flat Bootstrap Responsive Website Template | Contact :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Vigor Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='//fonts.googleapis.com/css?family=Simonetta:400,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Questrial' rel='stylesheet' type='text/css'>
<script src="js/bootstrap.min.js"></script>
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
<body>
<!--header-->
<div class="header">
	<div class="container">
		<div class="header-top">
			<div class="col-sm-3 header-login">
				<div class=" logo animated wow shake" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h1><a href="index.html">City 360</a>	</h1>
				</div>
			</div>	
			<div class="col-sm-9 header-social ">
							
					<ul class="social-icon">
						<li><a href="#" ><i></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
						<li><a href="#"><i class="ic4"></i></a></li>
					</ul>
					<div class="clearfix"> </div>
     		<div class="head">
			<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
						
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					 <ul class="nav navbar-nav">
						<li ><a class="nav-in" href="AboutUs.php"><span data-letters="About Us">About Us</span></a> </li>
						<li ><a class="nav-in" href="Login.php"><span data-letters="Login">Login</span></a> </li>
						<li><a class="nav-in" href="WorkerReg.php"><span data-letters="Worker Registration">Worker Registration</span></a></li>
						<li ><a class="nav-in" href="CustomerReg.php"><span data-letters="Customer Registration">Customer Registration</span></a> </li>
						
						<!--<li><a class="nav-in" href="gallery.html"><span data-letters="Gallery">Gallery</span></a></li>
						<li><a class="nav-in" href="codes.html"><span data-letters="Codes">Codes</span></a></li>
						<li><a class="nav-in" href="contact.html"><span data-letters="Contact">Contact</span></a></li>-->
					</ul>
					   <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control form-cont" value="Search" onFocus="this.value='';" onBlur="if (this.value == '') {this.value ='Search';}">
        </div>
        <button type="submit" class="btn-search"></button>
      </form>
					</div><!-- /.navbar-collapse -->
					
				</nav>
				
		</div>
					
			</div>
				<div class="clearfix"> </div>
		</div>

	</div>
</div>
<!--content-->
<!-- map -->
<div class="contact">
	<h2> Customer Registration</h2>
	<div class="map">
		
	</div>

<div class="map-grids animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
	
		
		<div class="col-md-8 map-middle">
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  REGISTRATION FORM
  <table class="table">
    <tr>
      <td width="112">CustomerID</td>
      <td width="223"><label>
	  <?php 
	    mysqli_connect("localhost","root","","city360");
 		// mysqli_select_db("city360");
		$res=mysql_query("select (max(CustomerID)+1) as ids from customerreg");
		$data=mysql_fetch_assoc($res);
		$id=$data["ids"];
		?>
        <input name="CustomerID" type="text" value="<?php echo $id; ?>" required id="CustomerID" />
      </label></td>
    </tr>
    <tr>
      <td>First Name </td>
      <td><input name="FirstName" type="text" pattern="[a-zA-Z'-'\s]*" required id="FirstName" /></td>
    </tr>
    <tr>
      <td>Middle Name </td>
      <td><input name="MiddleName"  pattern="[a-zA-Z'-'\s]*"  type="text" id="MiddleName" /></td>
    </tr>
    <tr>
      <td>Last Name </td>
      <td><input name="LastName"  pattern="[a-zA-Z'-'\s]*" type="text" id="LastName" /></td>
    </tr>
    <tr>
      <td>Gender</td>
      <td><p>
        <label>
          <input type="radio" name="Gender" value="Male" />
          Male</label>
        <input type="radio" name="Gender" value="Female" />
        <label>Female</label>
        <label></label>
        </p>        
      <label></label></td>
    </tr>
    <tr>
      <td>Age</td>
      <td><input name="Age" type="text"  pattern="\d{2}" required id="Age" /></td>
    </tr>
    <tr>
      <td>House Name </td>
      <td><input name="HName"  pattern="[a-zA-Z'-'\s]*" type="text" required id="HName" /></td>
    </tr>
    <tr>
      <td>Place</td>
      <td><input name="Place"  pattern="[a-zA-Z'-'\s]*" type="text" required id="Place" /></td>
    </tr>
    <tr>
      <td>Post Office </td>
      <td><input name="PostOffice" type="text" required id="PostOffice" /></td>
    </tr>
    <tr>
      <td>Pincode</td>
      <td><input name="Pincode" type="text" pattern="\d{6}" required id="Pincode" /></td>
    </tr>
    <tr>
      <td>State</td>
      <td><label>
        <select name="State" id="State">
		<option>Kerala</option>
		</select>
      </label></td>
    </tr>
    <tr>
      <td>District</td>
      <td><label>
        <select name="District" id="District">
		<option>Kasargod</option>
		<option>Kannur</option>
		<option>Wayanad</option>
		<option>Kozhikode</option>
		<option>Malappuram</option>
		<option>Palakkad</option>
		<option>Thrissur</option>
		<option>Ernakulam</option>
		<option>Idukki</option>
		<option>Kottayam</option>
		<option>Alappuzha</option>
		<option>Pathanamthitta</option>
		<option>Kollam</option>
		<option>Thiruvananthapuram</option>
        </select>
      </label></td>
    </tr>
    <tr>
      <td>Email ID </td>
      <td><input name="EmailID" type="email" required id="EmailID" /></td>
    </tr>
    <tr>
      <td>Phone No </td>
      <td><input name="PhNo" type="text" pattern="/d{10}" required id="PhNo" /></td>
    </tr>
    <tr>
      <td>Photo</td>
      <td><label>
        <input name="Photo" type="file" required id="Photo" />
      </label></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input name="Password" type="password" required id="Password" /></td>
    </tr>
    <tr>
      <td>Confirm Password </td>
      <td><input name="ConfirmPassword" type="password" required id="ConfirmPassword" /></td>
    </tr>
    <tr>
      <td>Approval Status </td>
      <td><input name="ApprovStatus" type="text" required id="ApprovStatus" /></td>
    </tr>
  </table>
  <label>
  <input type="submit" name="Submit" value="Submit" />
  </label>
   <?php
  if(isset($_REQUEST["Submit"]))
  {
  mysql_connect("localhost","root","");
  mysql_select_db("city360");
  $id=$_REQUEST["CustomerID"];
  $fname=$_REQUEST["FirstName"];
  $mname=$_REQUEST["MiddleName"];
  $lname=$_REQUEST["LastName"];
  $gender=$_REQUEST["Gender"];
  $age=$_REQUEST["Age"];
  $hname=$_REQUEST["HName"];
  $place=$_REQUEST["Place"];
  $po=$_REQUEST["PostOffice"];
  $pin=$_REQUEST["Pincode"];
  $state=$_REQUEST["State"];
  $district=$_REQUEST["District"];
  $email=$_REQUEST["EmailID"];
  $phno=$_REQUEST["PhNo"];
  $pic=$_FILES["Photo"]["name"];
  $password=$_REQUEST["Password"];
  $cpassword=$_REQUEST["ConfirmPassword"];
  $astatus=$_REQUEST["ApprovStatus"];
  
  $allowed_filetypes = array('.jpg','.jpeg','.png','.gif');
$max_filesize = 10485760;
$upload_path = 'img/';

$filename = $_FILES['Photo']['name'];
move_uploaded_file($_FILES['Photo']['tmp_name'],$upload_path . $filename);
$rr=mysql_query(" select count(*) as cnt from login where Username='$email' and Password='$password'");
$da=mysql_fetch_assoc($da);
if($da["cnt"]==0)
{
  mysql_query("insert into customerreg values('$id','$fname','$mname','$lname','$gender','$age','$hname','$place','$po','$pin','$state','$district','$email','$phno','$pic','$password','$cpassword','$astatus')");
   mysql_query("insert into login  values('$email','$password','Customer')");
}
else{
  echo"<script>alert('User already exist')</script>";
}
  }
  ?>
  
</form>
</div>
		<div class="col-md-4 map-left">
			<h3>Address</h3>
				<div class="call">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<ul>
							<li>+3402 890 679</li>
							<li>+5356 890 679</li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="call">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-send" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<ul>
							<li>345 Diamond Street,</li>
							<li>Greece.</li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="call">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<ul>
							<li><a href="mailto:info@example.com">info@example.com</a></li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>

		</div>
		<div class="clearfix"></div>
	</div>

</div>
<!-- //map -->

 		<!--//content-slide-->
</div>
</body>
</html>