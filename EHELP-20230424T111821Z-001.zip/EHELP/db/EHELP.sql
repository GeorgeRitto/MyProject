/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.5.8-log : Database - city360
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`city360` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `city360`;

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `categorry` (
  `CategoryID` int(11) NOT NULL,
  `Category` varchar(20) NOT NULL,
  `Subcategory` varchar(20) NOT NULL,
  `Workers` int(11) NOT NULL,
  `Salary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`CategoyID`,`Category`,`Subcategory`,`Workers`,`Salary`) values (1,'kl','lk',5,1000),(1,'kl','lk',5,1000);

/*Table structure for table `changepassword` */

DROP TABLE IF EXISTS `changepassword`;

CREATE TABLE `changepassword` (
  `CurrentPassword` varchar(20) NOT NULL,
  `NewPassword` varchar(20) NOT NULL,
  `ConfirmPasword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `changepassword` */

insert  into `changepassword`(`CurrentPassword`,`NewPassword`,`ConfirmPasword`) values ('Ann','Susan','Susan'),('Ann','Susan','Susan');

/*Table structure for table `customerordercancel` */

DROP TABLE IF EXISTS `customerordercancel`;

CREATE TABLE `cusomerordercancel` (
  `Date` date NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `OrderID` int(11) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Reason` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customerordercancel` */

insert  into `customerordercancel`(`Date`,`CustomerID`,`OrderID`,`Status`,`Reason`) values ('2017-12-21',201,0,'Cancelled','Nothing'),('2017-12-21',201,0,'Cancelled','Nothing'),('2017-12-21',100,1,'Postponed','Nothing'),('2017-12-21',201,0,'Cancelled','Nothing'),('2017-12-21',201,0,'Cancelled','Nothing'),('2017-12-21',100,1,'Postponed','Nothing');

/*Table structure for table `customerreg` */

DROP TABLE IF EXISTS `customerreg`;

CREATE TABLE `customerreg` (
  `CustomerID` varchar(20) NOT NULL,
  `Firstname` varchar(20) NOT NULL,
  `Middlename` varchar(20) NOT NULL,
  `Lastname` varchar(20) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Age` int(11) NOT NULL,
  `Housename` varchar(20) NOT NULL,
  `Place` varchar(20) NOT NULL,
  `Postoffice` varchar(20) NOT NULL,
  `Pincode` int(11) NOT NULL,
  `State` varchar(10) NOT NULL,
  `District` varchar(20) NOT NULL,
  `EmailID` varchar(30) NOT NULL,
  `PhoneNo` varchar(11) NOT NULL,
  `Photo` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `ConfirmPassword` varchar(20) NOT NULL,
  `ApprovalStatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customerreg` */

insert  into `customerreg`(`CustomerID`,`Firstname`,`Middlename`,`Lastname`,`Gender`,`Age`,`Housename`,`Place`,`Postoffice`,`Pincode`,`State`,`District`,`EmailID`,`PhoneNo`,`Photo`,`Password`,`ConfirmPassword`,`ApprovalStatus`) values ('100','Ann','Liya','John','Female',23,'Njalil','Eroor','Vymeethi',685349,'Andhra Pra','Kasargod','anju@gmail.com','2147483647','18BABFB3-A62C-4D97-A78B-F3CAFD288C95.jpg','ann','ann','Approved'),('101','Ansa','Sara','Saju','Female',20,'Oorath','Idukki','Kuttikkanam',685427,'Kerala','Ernakulam','ann@gmail.com','2147483647','18BABFB3-A62C-4D97-A78B-F3CAFD288C95.jpg','ansa','ansa','Approved'),('102','Basil','Babu','Paul','Male',30,'Kizhakkedath','Kottayam','Konkanur',654327,'Madhya Pra','Thrissur','wersa@gmail.com','2147483647','1a150824f2bb35c2b1af156494751b67.jpg','basil','basil','Pending'),('100','Ann','Liya','John','Female',23,'Njalil','Eroor','Vymeethi',685349,'Andhra Pra','Kasargod','anju@gmail.com','2147483647','18BABFB3-A62C-4D97-A78B-F3CAFD288C95.jpg','ann','ann','Approved'),('101','Ansa','Sara','Saju','Female',20,'Oorath','Idukki','Kuttikkanam',685427,'Kerala','Ernakulam','ann@gmail.com','2147483647','18BABFB3-A62C-4D97-A78B-F3CAFD288C95.jpg','ansa','ansa','Approved'),('102','Basil','Babu','Paul','Male',30,'Kizhakkedath','Kottayam','Konkanur',654327,'Madhya Pra','Thrissur','wersa@gmail.com','2147483647','1a150824f2bb35c2b1af156494751b67.jpg','basil','basil','Pending'),('1','manu','mm','m','Male',25,'kripa','tvr','ekm',6259,'Andhra Pra','Kasargod','manu@mm.com','9895188974','16426179_1911302985865143_5226497432792769339_n.jp','manu','manu','Approved'),('655','Appu','Unni','Thakku','Female',21,'cyuiub','gcuvyhv','gcuibj',5586897,'Kerala','Kasargod','ans@wer.com','78534376098','Remya Ravi 20170329_171403.jpg','ans','ans','Approved'),('112','kl','kl','kl','Male',20,'kkkll','tvr','123',1234,'Kerala','Kasargod','kll@kll.cc','1234','te.jpg','123','123','Approved'),('656','shahbh','fyuuhb','ayugaf','Female',21,'dtxytvij','gctuuib','frdtfyiuh',789456,'Kerala','Kasargod','ann@p.com','98765432223','Remya Ravi 20170329_171403.jpg','annp','annp','Approved');

/*Table structure for table `feedback` */

DROP TABLE IF EXISTS `feedback`;

CREATE TABLE `feedback` (
  `Date` date NOT NULL,
  `Customer ID` varchar(20) NOT NULL,
  `Worker ID` varchar(20) NOT NULL,
  `Feedback` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `feedback` */

insert  into `feedback`(`Date`,`Customer ID`,`Worker ID`,`Feedback`) values ('2000-01-04','2','2','jjkkjhj'),('2000-01-04','2','2','jjkkjhj');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`Username`,`Password`,`Type`) values ('admin','admin','admin'),('manu@mm.com','manu','Customer'),('ann@sp.com','asp','Wotker'),('anu@mg.com','anu','Worker'),('ans@wer.com','ans','Customer'),('kll@kll.cc','123','Customer'),('ann@p.com','annp','Customer'),('vh@hh.com','uuu','Worker'),('22@22.com','22','Worker'),('amal@gmail.com','amal','Worker');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `OrderID` int(11) NOT NULL,
  `CustomerID` varchar(20) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `Work` varchar(100) NOT NULL,
  `Duedate` date NOT NULL,
  `Duetime` time NOT NULL,
  `WorkerID` varchar(50) NOT NULL,
  `No.of.days` int(11) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `order` */

insert  into `order`(`OrderID`,`CustomerID`,`Date`,`Time`,`CategoryID`,`Work`,`Duedate`,`Duetime`,`WorkerID`,`No.of.days`,`Status`) values (1,'2','2000-01-01','02:00:00',2,'pol','2001-09-09','03:00:00','kjkjk',2,'Approved'),(76,'543','2016-06-06','12:20:15',14,'gcdfiugj','2016-07-04','12:40:20','123',2,'Rejected'),(12,'334','2016-07-05','11:10:07',467,'hxugj','1998-09-09','08:04:06','253',2,'Approved'),(12,'876','0000-00-00','00:00:00',387,'yugjkbkn','0000-00-00','00:00:00','286',5,'Approved'),(1,'2','2000-01-01','02:00:00',2,'pol','2001-09-09','03:00:00','kjkjk',2,'Approved'),(76,'543','2016-06-06','12:20:15',14,'gcdfiugj','2016-07-04','12:40:20','123',2,'Rejected'),(12,'334','2016-07-05','11:10:07',467,'hxugj','1998-09-09','08:04:06','253',2,'Approved'),(12,'876','0000-00-00','00:00:00',387,'yugjkbkn','0000-00-00','00:00:00','286',5,'Approved'),(24,'1','1996-07-31','12:00:00',1,'saxuyuhb','2000-04-04','10:00:00','286',2,'Booked'),(333,'655','2012-04-12','12:00:00',1,'sytdyfigj','2012-08-12','01:09:09','thvb',4,'Approved'),(334,'655','2017-04-22','00:00:00',1,'afYFYIVJBJL','1998-08-12','12:00:00','',3,'Approved');

/*Table structure for table `payment1` */

DROP TABLE IF EXISTS `payment1`;

CREATE TABLE `payment1` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `servicecharge` varchar(50) NOT NULL,
  `expertname` varchar(50) NOT NULL,
  `amount` int(50) NOT NULL,
  `cardholder` varchar(50) NOT NULL,
  `pin` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `payment1` */

insert  into `payment1`(`id`,`servicecharge`,`expertname`,`amount`,`cardholder`,`pin`) values (2,'250','amal',500,'kll',12345);

/*Table structure for table `workerordercancel` */

DROP TABLE IF EXISTS `workerordercancel`;

CREATE TABLE `workerordercancel` (
  `Date` date NOT NULL,
  `WorkerID` int(11) NOT NULL,
  `OrderID` int(11) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Reason` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `workerordercancel` */

insert  into `workerordercancel`(`Date`,`WorkerID`,`OrderID`,`Status`,`Reason`) values ('2016-08-12',0,1,'radio','No Current'),('2016-06-30',120,2,'Postponed','No Reason'),('2016-08-12',0,1,'radio','No Current'),('2016-06-30',120,2,'Postponed','No Reason');

/*Table structure for table `workerreg` */

DROP TABLE IF EXISTS `workerreg`;

CREATE TABLE `workerreg` (
  `WorkerID` int(10) NOT NULL,
  `Firstname` varchar(10) NOT NULL,
  `Middlename` varchar(10) NOT NULL,
  `Lastname` varchar(10) NOT NULL,
  `Gender` varchar(8) NOT NULL,
  `Photo` varchar(500) NOT NULL,
  `DOB` date NOT NULL,
  `Age` int(11) NOT NULL,
  `Housename` varchar(20) NOT NULL,
  `Place` varchar(20) NOT NULL,
  `Postoffice` varchar(20) NOT NULL,
  `Pincode` int(11) NOT NULL,
  `State` varchar(10) NOT NULL,
  `District` varchar(20) NOT NULL,
  `EmailID` varchar(30) NOT NULL,
  `PhoneNo` varchar(11) NOT NULL,
  `Category` varchar(20) NOT NULL,
  `Qualification` varchar(25) NOT NULL,
  `Experience` int(11) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `ConfirmPassword` varchar(20) NOT NULL,
  `ApprovalStatus` varchar(20) NOT NULL,
  `FeedbackStatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `workerreg` */

insert  into `workerreg`(`WorkerID`,`Firstname`,`Middlename`,`Lastname`,`Gender`,`Photo`,`DOB`,`Age`,`Housename`,`Place`,`Postoffice`,`Pincode`,`State`,`District`,`EmailID`,`PhoneNo`,`Category`,`Qualification`,`Experience`,`Password`,`ConfirmPassword`,`ApprovalStatus`,`FeedbackStatus`) values (123,'Ann','Susan','Paul','Female','18BABFB3-A62C-4D97-A','0000-00-00',20,'Chemmala','Oorakkad','Vilangue',683561,'Kerala','Ernakulam','nn2@gmail.com','9961535698','Electrician','diploma',6,'asff','ann','Approved','Good'),(124,'Meenu','Sara','Rohan','Female','16112932_18723446330','0000-00-00',30,'Vadakkedath','Karimugal','Peringala',659824,'Andhra Pra','Kasargod','sara@yahoo.com','2147483647','Mechanic','BscElectronics',2,'ann','sara','Approved','Excellent'),(253,'Leena','Minu','Alias','Female','33aba71.jpg','1997-12-21',23,'Kolujgrfvj','Pallikkara','akatufvhj',637532,'Mizoram','Kozhikode','adyg@gmail.com','2147483647','Electrician','BscElectronics',2,'ann','ehu3','Approved','suvyu'),(253,'Leena','Minu','Alias','Female','33aba71.jpg','1997-12-21',23,'Kolujgrfvj','Pallikkara','akatufvhj',637532,'Mizoram','Kozhikode','adyg@gmail.com','2147483647','Electrician','BscElectronics',2,'ann','ehu3','Approved','suvyu'),(286,'sfyufy','yufyfi','yuf7u','Male','16196041_13887124011','1996-04-04',21,'yhvuib','cyuvijkm','vivjb',665334,'Andhra Pra','Kasargod','cuyfiu@igu','2147483647','Electrician','BscElectronics',2,'ann','cyufyg','',''),(0,'asyu','djhvy','qwdf','Male','33aba71.jpg','1996-08-21',20,'aef','effe','werf',241341,'Andhra Pra','Kasargod','sfeg@rgeq','2424242442','Electrician','gergd',3,'efggaf','ergr','',''),(123,'Ann','Susan','Paul','Female','18BABFB3-A62C-4D97-A','0000-00-00',20,'Chemmala','Oorakkad','Vilangue',683561,'Kerala','Ernakulam','nn2@gmail.com','9961535698','Electrician','diploma',6,'asff','ann','Approved','Good'),(124,'Meenu','Sara','Rohan','Female','16112932_18723446330','0000-00-00',30,'Vadakkedath','Karimugal','Peringala',659824,'Andhra Pra','Kasargod','sara@yahoo.com','2147483647','Mechanic','BscElectronics',2,'ann','sara','Approved','Excellent'),(253,'Leena','Minu','Alias','Female','33aba71.jpg','1997-12-21',23,'Kolujgrfvj','Pallikkara','akatufvhj',637532,'Mizoram','Kozhikode','adyg@gmail.com','2147483647','Electrician','BscElectronics',2,'ann','ehu3','Approved','suvyu'),(253,'Leena','Minu','Alias','Female','33aba71.jpg','1997-12-21',23,'Kolujgrfvj','Pallikkara','akatufvhj',637532,'Mizoram','Kozhikode','adyg@gmail.com','2147483647','Electrician','BscElectronics',2,'ann','ehu3','Approved','suvyu'),(286,'sfyufy','yufyfi','yuf7u','Male','16196041_13887124011','1996-04-04',21,'yhvuib','cyuvijkm','vivjb',665334,'Andhra Pra','Kasargod','cuyfiu@igu','2147483647','Electrician','BscElectronics',2,'ann','cyufyg','',''),(0,'asyu','djhvy','qwdf','Male','33aba71.jpg','1996-08-21',20,'aef','effe','werf',241341,'Andhra Pra','Kasargod','sfeg@rgeq','2424242442','Electrician','gergd',3,'efggaf','ergr','',''),(1,'Ann','Susan','Paul','Female','7ad1ef512f20f540a2da','1996-08-12',20,'Chemmala','Oorakkad','Vilangue',683516,'Kerala','Kozhikode','ann@sp.com','9961535698','1','shcyigu',3,'asp','auh','Approved',''),(2,'Remya','Amru','Paul','Female','6efc507b47cae4b7c176','2017-04-04',1,'syf8g','ugvoyyg','vyvyijbj',654745,'Andhra Pra','Kasargod','ann@sp.com','9787865434','1','sdfyadiuqhwduib',2,'asp','asp','Approved',''),(5,'eygeuok','yguguih','dfyih','Female','7c0ea2df78ffe0c51334','2017-04-05',1,'vtcuvim','gctvuhbj','cgycuhv',4655478,'Andhra Pra','Kasargod','anu@mg.com','8675443456','1','sytfij',1,'anu','anu','Approved',''),(287,'dabfueoi','aefqg','ewgwg','Male','98a67a6371feb9bc96d6','2012-04-04',23,'dshik','vviujb','hcyuugu',57868,'Kerala','Kasargod','vh@hh.com','4657608','1','chjbjk',4,'uuu','uuu','Approved',''),(288,'ctcyvh','hvyviub','vyviu','Female','98a67a6371feb9bc96d60cec7b676be3.jpg','2012-08-12',21,'vhvyg','fufiiujb','gcvjkbkln',87655,'Kerala','Kasargod','22@22.com','8974543','1','xfcguvhjb',7,'22','22','',''),(289,'amal','m','mathew','Male','3d_Heart.jpg','1994-01-02',23,'zdf','ernakulam','kaloor',897654,'Kerala','Ernakulam','amal@gmail.com','9876545678','1','degree',3,'amal','amal','Approved','Good');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
