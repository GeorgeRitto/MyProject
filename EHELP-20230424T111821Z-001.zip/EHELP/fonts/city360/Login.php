<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Vigor A Industrial Category Flat Bootstrap Responsive Website Template | Contact :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Vigor Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='//fonts.googleapis.com/css?family=Simonetta:400,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Questrial' rel='stylesheet' type='text/css'>
<script src="js/bootstrap.min.js"></script>
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
<body>
<!--header-->
<div class="header">
	<div class="container">
		<div class="header-top">
			<div class="col-sm-3 header-login">
				<div class=" logo animated wow shake" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h1><a href="index.html">City 360</a>	</h1>
				</div>
			</div>	
			<div class="col-sm-9 header-social ">
							
					<ul class="social-icon">
						<li><a href="#" ><i></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
						<li><a href="#"><i class="ic4"></i></a></li>
					</ul>
					<div class="clearfix"> </div>
     		<div class="head">
			<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
						
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					 <ul class="nav navbar-nav">
						<li ><a class="nav-in" href="AboutUs.php"><span data-letters="About Us">About Us</span></a> </li>
						<li ><a class="nav-in" href="Login.php"><span data-letters="Login">Login</span></a> </li>
						<li><a class="nav-in" href="WorkerReg.php"><span data-letters="Worker Registration">Worker Registration</span></a></li>
						<li ><a class="nav-in" href="CustomerReg.php"><span data-letters="Customer Registration">Customer Registration</span></a> </li>
						
						<!--<li><a class="nav-in" href="gallery.html"><span data-letters="Gallery">Gallery</span></a></li>
						<li><a class="nav-in" href="codes.html"><span data-letters="Codes">Codes</span></a></li>
						<li><a class="nav-in" href="contact.html"><span data-letters="Contact">Contact</span></a></li>-->
					</ul>
					   <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control form-cont" value="Search" onFocus="this.value='';" onBlur="if (this.value == '') {this.value ='Search';}">
        </div>
        <button type="submit" class="btn-search"></button>
      </form>
					</div><!-- /.navbar-collapse -->
					
				</nav>
				
		</div>
					
			</div>
				<div class="clearfix"> </div>
		</div>

	</div>
</div>
<!--content-->
<!-- map -->
<div class="contact">
	<h2> Login </h2>
	<div class="map">
		
	</div>

<div class="map-grids animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
	
		
		<div class="col-md-8 map-middle">
<form id="form1" name="form1" method="post" action="">
  LOGIN
  <table class="table">
    <tr>
      <td width="90">User Name</td>
      <td width="144"><label>
        <input name="Username" type="text" required id="Username"placeholder="enter email_id" />
      </label></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input name="Password" type="password" required id="Password"placeholder="enter password" /></td>
    </tr>
  </table>
  <label>
  <input type="submit" name="Submit" value="Submit" />
  <a href="ForgotPassword.php">Forgot Password</a>
  <a href="ChangePassword.php">Change Password</a>
  </label>
   <?php
   session_start();
   
  if(isset($_REQUEST["Submit"]))
  {
  mysql_connect("localhost","root","");
  mysql_select_db("smartfinder");
  $uname=$_REQUEST["Username"];
  $password=$_REQUEST["Password"];
  $_SESSION["uname"]=$uname;
$res=  mysql_query("select type from  login where Username='$uname' and Password='$password'");

$data=mysql_fetch_assoc($res);
$type=$data["type"];
if($type=="Customer")
{
	$res=   mysql_query("select CustomerID from  customerreg where EmailID='$uname' ");

$data=mysql_fetch_assoc($res);
$_SESSION["cid"]=$data["CustomerID"];
	header("Location:CustomerProfile.php");
}
else if($type=="Worker")
{
		$res=   mysql_query("select WorkerID from  workerreg where EmailID='$uname' ");

$data=mysql_fetch_assoc($res);
$_SESSION["wid"]=$data["WorkerID"];
header("Location:WorkerProfile.php");

}
else if($type=="admin")
{
	header("Location:Category.php");
}
else
{
	echo"<script>alert('Invalid Username and Password')</script>";
}
	}
	?>
</form>
</div>
		<div class="col-md-4 map-left">
			<h3>Address</h3>
				<div class="call">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<ul>
							<li>+3402 890 679</li>
							<li>+5356 890 679</li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="call">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-send" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<ul>
							<li>345 Diamond Street,</li>
							<li>Greece.</li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="call">
					<div class="col-xs-3 contact-grdl">
						<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
					</div>
					<div class="col-xs-9 contact-grdr">
						<ul>
							<li><a href="mailto:info@example.com">info@example.com</a></li>
						</ul>
					</div>
					<div class="clearfix"> </div>
				</div>

		</div>
		<div class="clearfix"></div>
	</div>

</div>
<!-- //map -->

 		<!--//content-slide-->
</div>
<div class="footer animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
	<div class="container">
			<h4>denouncing pleasure</h4>
			<p class="footer-in">But I must explain to you how all this mistaken <br>idea of denouncing pleasure <br>and praising pain </p>
			<ul class="footer-top">
			<li><span><i class="glyphicon glyphicon-earphone"></i>+123456789</span></li>
			<li><a href="mailto:info@example.com"><i class="glyphicon glyphicon-envelope"></i> Lorem@example.com</a>
			</ul>
<p class="footer-class"> © 2016 Vigor . All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>		
	</div>
</div>	
</body>
</html>