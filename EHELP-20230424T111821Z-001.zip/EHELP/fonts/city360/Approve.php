<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  	<?php
	$id=$_GET["id"];
	$status=$_GET["Status"];
	
	 mysql_connect("localhost","root","");
  mysql_select_db("smartfinder");
  if($status=="Approved")
  {
   $res=mysql_query("Update `order` set Status='Approved' where OrderID='$id'");
   header("Location:OrderApproval.php");
   }
    if($status=="Rejected")
  {
   $res=mysql_query("Update `order` set Status='Rejected' where OrderID='$id'");
    header("Location:OrderApproval.php");
   }

	?>
 </form>
</body>
</html>
