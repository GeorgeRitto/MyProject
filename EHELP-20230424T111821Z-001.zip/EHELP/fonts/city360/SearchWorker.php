<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Vigor A Industrial Category Flat Bootstrap Responsive Website Template | Contact :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Vigor Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='//fonts.googleapis.com/css?family=Simonetta:400,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Questrial' rel='stylesheet' type='text/css'>
<script src="js/bootstrap.min.js"></script>
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
<body>
<!--header-->
<div class="header">
	<div class="container">
		<div class="header-top">
			<div class="col-sm-3 header-login">
				<div class=" logo animated wow shake" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h1><a href="index.html">City 360</a>	</h1>
				</div>
			</div>	
			<div class="col-sm-9 header-social ">
							
					<ul class="social-icon">
						<li><a href="#" ><i></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
						<li><a href="#"><i class="ic4"></i></a></li>
					</ul>
					<div class="clearfix"> </div>
     		<div class="head">
			<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
						
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
	<ul class="nav navbar-nav">
						<li ><a class="nav-in" href="CustomerProfile.php"><span data-letters="Profile">Profile</span></a> </li>
			
						<li ><a class="nav-in" href="SearchWorker.php"><span data-letters="Search">Search</span></a> </li>
						<li ><a class="nav-in" href="payment1.php"><span data-letters="Search">Payment</span></a> </li>
						
                        <li><a class="nav-in" href="viewworkstatus.php"><span data-letters="Work Status">Work Status</span></a></li>
						<li ><a class="nav-in" href="CustomerOrderCancel.php"><span data-letters="Cancel Order">Cancel Order</span></a> </li>
						<li><a class="nav-in" href="Feedback.php"><span data-letters="Feedback">Feedback</span></a></li>
					<li><a class="nav-in" href="Login.php"><span data-letters="Log Out">Log Out</span></a></li>
                   <!-- <li><a class="nav-in" href="Login.php"><span data-letters="LogOut">LogOut</span></a></li>-->
						<!--<li><a class="nav-in" href="codes.html"><span data-letters="Codes">Codes</span></a></li>
						<li><a class="nav-in" href="contact.html"><span data-letters="Contact">Contact</span></a></li>-->
					</ul>					   <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control form-cont" value="Search" onFocus="this.value='';" onBlur="if (this.value == '') {this.value ='Search';}">
        </div>
        <button type="submit" class="btn-search"></button>
      </form>
					</div><!-- /.navbar-collapse -->
					
				</nav>
				
		</div>
					
			</div>
				<div class="clearfix"> </div>
		</div>

	</div>
</div>
<!--content-->
<!-- map -->
<div class="contact">
	<h2> Search Worker</h2>
	<div class="map">
		
	</div>

<div class="map-grids animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
	
		
		<div class="col-md-8 map-middle">
<form id="form1" name="form1" method="post" action="">
  <label>SEARCH CATEGORY<br />
  Enter The Category 
  <input name="Cat" type="text" id="Cat" />
  </label>
  <label>
  <input name="Search" type="submit" id="Search" value="Search" />
  
  <p>Search Results:</p>
  <table width="200" border="1">
    <tr>
      <td>Worker ID </td>
      <td>Name</td>
    </tr>
	 <?php
  if(isset($_REQUEST["Search"]))
  {
  mysql_connect("localhost","root","");
  mysql_select_db("smartfinder");
 $cat=$_REQUEST["Cat"];
 //$dfrom=$_REQUEST["From"];
 //$dto=$_REQUEST["To"];
  $res=mysql_query("select * from workerreg where Category='$cat' and WorkerID not in(Select WorkerID from `order` where Status='Approved' )");
  while($data=mysql_fetch_assoc($res))
{
$workerid=$data["WorkerID"];
echo "<tr><td>".$data["WorkerID"]."</td><td>".$data["Firstname"]."   ".$data["Middlename"]." ".$data["Lastname"]."</td><td><a href='Order.php?id=$workerid'>Book</a></td></tr>";
}
}
 ?>
  </table>
</form>
</body>
</html>