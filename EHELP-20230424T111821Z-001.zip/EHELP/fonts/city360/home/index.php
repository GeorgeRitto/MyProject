<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">

<head>
	
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Cleaning Services Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/progresscircle.css">
	<!-- progress -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link rel="stylesheet" href="css/fontawesome-all.css">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=devanagari,latin-ext"
	    rel="stylesheet">
	<!-- //Web-Fonts -->

</head>

<body>
	<!-- header -->
	<header>
		<nav class="navbar navbar-expand-lg navbar-light py-0">
			<div class="container">
				<a class="navbar-brand" href="index.html">
					
				</a>
				<button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
				    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">

					<ul class="navbar-nav ml-auto text-center">
						<li class="nav-item active">
							<a class="nav-link" href="index.php">Home
								<span class="sr-only">(current)</span>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="../CustomerReg.php">Customer Registration</a>
						</li>
						
						<li class="nav-item">
							<a class="nav-link" href="../WorkerReg.php">Worker Registration</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="../login.php">Login </a>
						</li>
					</ul>
				</div>
			</div>
		</nav>
	</header>
	<!-- //header -->

	<!-- banner -->
	<div class="callbacks_container">
		<ul class="rslides" id="slider3">
			<li>
				<div class="slider-info banner-w3-1">
					<div class="w3l-overlay">
						<div class="banner-text text-center container">
							<h3 class="text-white mb-4 text-uppercase">Professional
								<span> cleaning services</span>
							</h3>
							<p class="movetxt text-white text-uppercase">We like when it's
								<span>clean around!</span> & We working hard to make your place
								<span>clean</span>
							</p>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="slider-info banner-w3-2">
					<div class="w3l-overlay">
						<div class="banner-text text-center container">
							<h3 class="text-white mb-4 text-uppercase">Professional
								<span> cleaning services</span>
							</h3>
							<p class="movetxt text-white text-uppercase">We like when it's
								<span>clean around!</span> & We working hard to make your place
								<span>clean</span>
							</p>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="slider-info banner-w3-3">
					<div class="w3l-overlay">
						<div class="banner-text text-center container">
							<h3 class="text-white mb-4 text-uppercase">Professional
								<span> cleaning services</span>
							</h3>
							<p class="movetxt text-white text-uppercase">We like when it's
								<span>clean around!</span> & We working hard to make your place
								<span>clean</span>
							</p>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
	<!-- //banner -->

	<!-- banner bottom -->
	<div class="about py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-5 agileits_works-grid">
					<h3 class="tittle mb-xl-5 mb-4 text-dark text-uppercase font-weight-bold pl-4 py-3">Welcome to our
						<span>Cleaning Services</span>
					</h3>
				</div>
				<div class="col-lg-7 agileits_works-grid1 mt-lg-0 mt-4">
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem
						aperiam,
						eaque ipsa quae ab illo inventore veritatis et quasi architecto.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- //banner bottom -->

	<!-- progress -->
	<div class="progress-w3ls py-5 text-center">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-md-3 col-sm-6">
					<div class="progress blue">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">90%</div>

					</div>
					<p class="text-white progress-texts mt-3">Satisfied Customers</p>
				</div>
				<div class="col-md-3 col-sm-6 mt-sm-0 mt-4">
					<div class="progress yellow">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">75%</div>

					</div>
					<p class="text-white progress-texts mt-3">Building Cleaned</p>
				</div>
				<div class="col-md-3 col-sm-6 mt-md-0 mt-4">
					<div class="progress green">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">75%</div>

					</div>
					<p class="text-white progress-texts mt-3">Clever Employee</p>
				</div>
				<div class="col-md-3 col-sm-6 mt-md-0 mt-4">
					<div class="progress pink">
						<span class="progress-left">
							<span class="progress-bar"></span>
						</span>
						<span class="progress-right">
							<span class="progress-bar"></span>
						</span>
						<div class="progress-value">75%</div>
					</div>
					<p class="text-white progress-texts mt-3">Shiny Cleaning</p>
				</div>
			</div>
		</div>
	</div>
	<!-- //progress -->

	<!-- middle section -->
	<section class="middle-w3ls py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-5 agileits_works-grid">
					<h2 class="tittle mb-xl-5 mb-4 text-white text-uppercase font-weight-bold pl-4 py-3">About Us</h2>
				</div>
				<div class="col-lg-7 para-right-title">
					<p class="py-3 text-white">Totam rem aperiam, eaque ipsa quae ab illo inventore explicabo.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6">
					<h4 class="text-white text-uppercase font-weight-bold">Cleaning Services</h4>
					<h6 class="text-white text-uppercase sec-text border-bottom pb-2 mt-4">Best Cleaning</h6>
					<p class="my-5 white-forming">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
						fugiat nulla pariatur. Excepteur sint
						occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<a href="about.html" class="btn btn-sm animated-button victoria-two">Read More</a>
				</div>
				<div class="col-lg-6 mt-sm-0 mt-3">
					<img src="images/a1.png" alt="" class="img-fluid" />
				</div>
			</div>
		</div>
	</section>
	<!-- //middle section -->

	<!-- services -->
	<section class="services-w3ls py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-5 agileits_works-grid">
					<h3 class="tittle mb-xl-5 mb-4 text-dark text-uppercase font-weight-bold pl-4 py-3">Our Services</h3>
				</div>
				<div class="col-lg-7 para-right-title">
					<p class="py-3">Totam rem aperiam, eaque ipsa quae ab illo inventore explicabo.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 p-sm-0">
					<div class="icons-w3ls text-white p-4">
						<i class="fas fa-braille py-4"></i>
						<h5 class="text-uppercase">Extra Shiny</h5>
					</div>
					<p class="p-4">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
						pariatur. Excepteur sint
						occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<a href="offers.html" class="btn btn-sm animated-button victoria-two text-dark mt-4">Read More</a>
				</div>
				<div class="col-md-4 p-sm-0 my-md-0 my-5">
					<div class="icons-w3ls text-white p-4 mid-sec-agile">
						<h5 class="text-uppercase pb-2 text-center">Trash treatment</h5>
						<i class="fas fa-align-center pt-4"></i>
					</div>
					<p class="p-4">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
						pariatur. Excepteur sint
						occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<a href="offers.html" class="btn btn-sm animated-button victoria-two text-dark mt-4">Read More</a>
				</div>
				<div class="col-md-4 p-sm-0">
					<div class="icons-w3ls text-white p-4">
						<i class="fas fa-quidditch py-4"></i>
						<h5 class="text-uppercase">Floor Cleaning</h5>
					</div>
					<p class="p-4">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
						pariatur. Excepteur sint
						occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<a href="offers.html" class="btn btn-sm animated-button victoria-two text-dark mt-4">Read More</a>
				</div>
			</div>
		</div>
	</section>
	<!-- //services -->

	<!-- mobile section -->
	<div class="feature py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-xl-3 col-lg-4">
					<div class="phone text-lg-left text-center">
						<img alt="" src="images/iphone.png" class="img-fluid phone-img-w3ls">
						<div class="iphone5-screen">
							<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
								<!-- Wrapper for slides -->
								<div class="carousel-inner">
									<div class="carousel-item item-1 active">
									</div>
									<div class="carousel-item item-2">
									</div>
									<div class="carousel-item item-3">
									</div>
									<div class="carousel-item item-4">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-8 col-lg-7 offset-xl-1 mt-4">
					<h3 class="text-white font-weight-bold text-mobile-w3">Get Satisfied with the services we provide A to Z in
						Cleaning</h3>
					<p class="white-forming my-4">Praesent congue iaculis pulvinar. Praesent sit amet consequat sem, nec scelerisque
						nisl.</p>
					<ul class="list-unstyled text-white">
						<li class="list-agiles">
							<i class="fas fa-check mr-2"></i>Window Cleaning</li>
						<li class="list-agiles my-3">
							<i class="fas fa-check mr-2"></i>Cloth Ironing</li>
						<li class="list-agiles my-3">
							<i class="fas fa-check mr-2"></i>Laundry</li>
						<li class="list-agiles my-3">
							<i class="fas fa-check mr-2"></i>Office Cleaning</li>
						<li class="list-agiles my-3">
							<i class="fas fa-check mr-2"></i>Construction Clean-Up</li>
						<li class="list-agiles my-3">
							<i class="fas fa-check mr-2"></i>Commercial Cleaning</li>
						<li class="list-agiles my-3">
							<i class="fas fa-check mr-2"></i>Move In/Move Out Cleaning</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- //mobile section -->

	<!-- posts -->
	<section class="news-w3ls py-5">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-lg-5 agileits_works-grid">
					<h3 class="tittle mb-xl-5 mb-4 text-dark text-uppercase font-weight-bold pl-4 py-3">Latest Posts</h3>
				</div>
				<div class="col-lg-7 para-right-title">
					<p class="py-3">Totam rem aperiam, eaque ipsa quae ab illo inventore explicabo irure dolor in reprehenderit sunt
						in culpa qui.
					</p>
				</div>
			</div>
			<div class="row package-grids mt-5">
				<div class="col-md-6 posts-w3ls">
					<div class="price-top">
						<a href="single.html">
							<img src="images/l2.jpg" alt="" class="img-fluid" />
						</a>
						<h3>13
							<span>August</span>
						</h3>
					</div>
					<div class="post-w3ls-bottom p-4 text-center">
						<h4 class="text-dark mb-3 mt-4">Sit voluptatem accus antium</h4>
						<ul class="list-unstyled">
							<li class="mr-2">
								<a href="single.html">
									<i class="fas fa-user mr-2"></i>Posted by accusantium</a>
							</li>
							<li>
								<a href="single.html">
									<i class="fas fa-comments mr-2"></i>488 Comments</a>
							</li>
						</ul>

						<p class="mt-4">sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
							nostrud exercitation</p>
					</div>
				</div>
				<div class="col-md-6 posts-w3ls mt-md-0 mt-4">
					<div class="price-top">
						<a href="single.html">
							<img src="images/l1.jpg" alt="" class="img-fluid" />
						</a>
						<h3>16
							<span>August</span>
						</h3>
					</div>
					<div class="post-w3ls-bottom p-4 text-center">
						<h4 class="text-dark mb-3 mt-4">Sit voluptatem accus antium</h4>
						<ul class="list-unstyled">
							<li class="mr-2">
								<a href="single.html">
									<i class="fas fa-user mr-2"></i>Posted by accusantium</a>
							</li>
							<li>
								<a href="single.html">
									<i class="fas fa-comments mr-2"></i>688 Comments</a>
							</li>
						</ul>

						<p class="mt-4">sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
							nostrud exercitation</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //posts -->

	<!-- footer -->
	<footer class="py-4">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-md-8 footer-title">
						<h1 class="tittle text-white text-uppercase font-weight-bold pl-4 py-3">Connect with Social</h1>
				</div>
				<div class="col-md-4 logo-2 text-md-right text-center mt-md-0 mt-4">
					<!-- social icons -->
					<div class="social-icons text-md-right text-center">
						<ul class="list-unstyled">
							<li>
								<a href="#" class="fab fa-facebook-f icon-border facebook rounded-circle"> </a>
							</li>
							<li class="mx-2">
								<a href="#" class="fab fa-twitter icon-border twitter rounded-circle"> </a>
							</li>
							<li>
								<a href="#" class="fab fa-google-plus-g icon-border googleplus rounded-circle"> </a>
							</li>
							<li class="ml-2">
								<a href="#" class="fas fa-rss icon-border rss rounded-circle"> </a>
							</li>
						</ul>
					</div>
					<!-- //social icons -->
				</div>
			</div>
			<div class="row">
				<div class="col-md-8 copy">
					<p class="mt-md-5 pt-md-4">&copy; 2018 Cleaning Services. All rights reserved | Design by
						<a href="http://w3layouts.com/">W3layouts</a>
					</p>
				</div>
				<div class="col-md-4 logo-2 text-md-right text-center">
					<a class="logo-footer" href="index.html">
						<img src="images/logo3.png" alt="" class="img-fluid">
					</a>
				</div>
			</div>
		</div>
	</footer>
	<!-- //footer -->

	<!-- Js files -->
	<!-- JavaScript -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<!-- Default-JavaScript-File -->

	<!-- Banner Responsiveslides -->
	<script src="js/responsiveslides.min.js"></script>
	<script>
		// You can also use "$(window).load(function() {"
		$(function () {
			// Slideshow 4
			$("#slider3").responsiveSlides({
				auto: true,
				pager: true,
				nav: false,
				speed: 500,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});

		});
	</script>
	<!-- // Banner Responsiveslides -->

	<!-- progresscircle -->
	<script src="js/progresscircle.js"></script>
	<script>
		$('.circlechart').circlechart(); // Initialization
	</script>
	<!-- //progresscircle -->

	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- move-top -->
	<script src="js/move-top.js"></script>
	<!-- easing -->
	<script src="js/easing.js"></script>
	<!--  necessary snippets for few javascript files -->
	<script src="js/cleaning.js"></script>

	<script src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->

	<!-- //Js files -->

</body>

</html>