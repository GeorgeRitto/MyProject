<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="200" border="1">
    <tr>
      <td>Worker ID</td>
      <td>Name</td>
      <td>Category</td>
    </tr>
	 <?php
mysql_connect("localhost","root","");
  mysql_select_db("smartfinder");
   $res=mysql_query("select * from workerreg where ApprovalStatus='Approved'");
while($data=mysql_fetch_assoc($res))
{echo "<tr><td>".$data["WorkerID"]."</td><td>".$data["Firstname"]."   ".$data["Middlename"]." ".$data["Lastname"]."</td><td>".$data["Category"]."</td></tr>";
}
  ?>
  </table>
</form>
</body>
</html>
