<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Vigor A Industrial Category Flat Bootstrap Responsive Website Template | Contact :: w3layouts</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Vigor Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='//fonts.googleapis.com/css?family=Simonetta:400,900' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Questrial' rel='stylesheet' type='text/css'>
<script src="js/bootstrap.min.js"></script>
<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>
<body>
<!--header-->
<div class="header">
	<div class="container">
		<div class="header-top">
			<div class="col-sm-3 header-login">
				<div class=" logo animated wow shake" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h1><a href="index.html">City 360</a>	</h1>
				</div>
			</div>	
			<div class="col-sm-9 header-social ">
							
					<ul class="social-icon">
						<li><a href="#" ><i></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
						<li><a href="#"><i class="ic4"></i></a></li>
					</ul>
					<div class="clearfix"> </div>
     		<div class="head">
			<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
						
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
	<ul class="nav navbar-nav">
		<li><a class="nav-in" href="WorkerProfile.php"><span data-letters="Profile">Profile</span></a></li>
						<li ><a class="nav-in" href="OrderApproval.php"><span data-letters="Approve Order">Approve Order</span></a> </li>
					
					<li><a class="nav-in" href="viewpayment.php"><span data-letters="Work Status">View Payment</span></a></li>
                        <li><a class="nav-in" href="WorkerOrderStatus.php"><span data-letters="Work Status">Work Status</span></a></li>
							<li ><a class="nav-in" href="WorkerOrderCancel.php"><span data-letters="Cancel Order">Cancel Order</span></a> </li>
					<li><a class="nav-in" href="Login.php"><span data-letters="Log Out">Log Out</span></a></li>
                   <!-- <li><a class="nav-in" href="Login.php"><span data-letters="LogOut">LogOut</span></a></li>-->
						<!--<li><a class="nav-in" href="codes.html"><span data-letters="Codes">Codes</span></a></li>
						<li><a class="nav-in" href="contact.html"><span data-letters="Contact">Contact</span></a></li>-->
					</ul>					   <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control form-cont" value="Search" onFocus="this.value='';" onBlur="if (this.value == '') {this.value ='Search';}">
        </div>
        <button type="submit" class="btn-search"></button>
      </form>
					</div><!-- /.navbar-collapse -->
					
				</nav>
				
		</div>
					
			</div>
				<div class="clearfix"> </div>
		</div>

	</div>
</div>
<!--content-->
<!-- map -->
<div class="contact">
	<h2 align="center"> Worker Profile</h2>
	<div class="map">
		
	</div>

<div class="map-grids animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="500ms">
	
		
		<div class="col-md-8 map-middle">
<label></label>
<label></label>
<form id="form1" name="form1" method="post" action="">
  <h1 align="center">WORKER PROFILE</h1>
 
<?php 
//$id=$_GET["id"];
session_start();
mysql_connect("localhost","root","");
  mysql_select_db("smartfinder");
   $res=mysql_query("select * from workerreg where Emailid='".$_SESSION["uname"]."'");
$data=mysql_fetch_assoc($res);
 $id=$data["WorkerID"];
  $fname=$data["Firstname"];
  $mname=$data["Middlename"];
  $lname=$data["Lastname"];
  $gender=$data["Gender"];
  $target_dir = "img/";
//$target_file = $target_dir . basename($_FILES["Photo"]["name"]);
//move_uploaded_file($_FILES["Photo"]["name"], $target_file);
//$pic=$_FILES["Photo"]["name"];
$pic=$data["Photo"];
  $dob=$data["DOB"];
  $age=$data["Age"];
  $hname=$data["Housename"];
  $place=$data["Place"];
  $po=$data["Postoffice"];
  $pin=$data["Pincode"];
  $state=$data["State"];
  $district=$data["District"];
  $email=$data["EmailID"];
  $phno=$data["PhoneNo"];
  $category=$data["Category"];
  $qualification=$data["Qualification"];
  $exp=$data["Experience"];
  $password=$data["Password"];
  if (isset($_REQUEST["Update"]))
  {
  $phno=$_REQUEST["PhoneNo"];
  $qualification=$_REQUEST["Qualification"];
  $exp=$_REQUEST["Experience"];
  $password=$_REQUEST["Password"];
  mysql_query("update workerreg set PhoneNo='$phno',Qualification='$qualification',Experience='$exp',Password='$password' where WorkerID='$id'");
}
	 ?>
  <table width="400" border="1" align="center">
    <tr>
      <td width="150">WorkerID</td>
      <td><?php echo $id ?></td>
    </tr>
    <tr>
      <td>First Name</td>
      <td><?php echo $fname ?></td>
    </tr>
    <tr>
      <td>Middle Name </td>
      <td><?php echo $mname ?></td>
    </tr>
    <tr>
      <td>Last Name </td>
      <td><?php echo $lname ?></td>
    </tr>
    <tr>
      <td>Gender</td>
      <td><?php echo $gender ?></td>
    </tr>
    <tr>
      <td>Photo</td>
      <td><img src="img/<?php echo $pic; ?>" width="150" /></td>
    </tr>
    <tr>
      <td>Date Of Birth </td>
      <td><?php echo $dob ?></td>
    </tr>
    
    <tr>
      <td>House Name </td>
      <td><?php echo $hname ?></td>
    </tr>
    <tr>
      <td>Place</td>
      <td><?php echo $place ?></td>
    </tr>
    <tr>
      <td>Post Office </td>
      <td><?php echo $po ?></td>
    </tr>
    <tr>
      <td>Pincode</td>
      <td><?php echo $pin ?></td>
    </tr>
    <tr>
      <td>State</td>
      <td><?php echo $state ?></td>
    </tr>
    <tr>
      <td>District</td>
      <td><?php echo $district ?></td>
    </tr>
    <tr>
      <td>Email-ID</td>
      <td><?php echo $email ?></td>
    </tr>
    <tr>
      <td>Phone No </td>
      <td><input type="text" name="PhoneNo" value="<?php echo $phno ?>" /></td>
    </tr>
    <tr>
      <td>Category</td>
      <td><?php echo $category ?></td>
    </tr>
    <tr>
      <td>Qualification</td>
      <td><input type="text" name="Qualification" value="<?php echo $qualification ?>" /></td>
    </tr>
    <tr>
      <td>Experience</td>
      <td><input type="text" name="Experience" value="<?php echo $exp ?>" /></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><input type="text" name="Password" value="<?php echo $password ?>" /></td>
    </tr>
  </table>
      <label>
      <input name="Update" type="submit" id="Update" value="Update" />
      </label>
      <?php
		
  if(isset($_REQUEST["v1"]))
  {
  
   $res=mysql_query("select * from workerreg where Emailid='".$_SESSION["uname"]."'");
$data=mysql_fetch_assoc($res);
 $id=$data["WorkerID"];

  
 header("Location:WorkerOrderCancel.php?id=".$id);
  }
  ?>
</form>
</body>
</html>
