from django.apps import AppConfig


class RoomManagerConfig(AppConfig):
    name = 'room_manager'
